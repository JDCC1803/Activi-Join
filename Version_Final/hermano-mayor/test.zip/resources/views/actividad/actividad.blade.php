@extends('dashboard')
@section('menor')
<div class="w-full mx-auto h-auto lg:mt-5 sm:mt-8">
    @livewire('ver-actividad')
</div>
@endsection