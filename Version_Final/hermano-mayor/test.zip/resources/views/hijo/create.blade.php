@extends('dashboard')
@section('mayor')
<div class="w-full mx-auto h-auto lg:mt-5 sm:mt-8">
    @livewire('agregar-miembro')
</div>
@endsection