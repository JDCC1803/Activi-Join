<div>
    {{-- Success is as dangerous as failure. --}}
    <div class="container mx-auto lg:mt-5 sm:mt-8">
        @if(count($new)>0)
        <div class="w-full flex flex-wrap h-full  lg:space-x-2 md:space-x-2 lg:space-y-0 md:space-y-0 sm:space-y-2">
            <div class=" px-4 lg:basis-2/3 md:basis-6/12 pb-4 sm:basis-11/12 lg:-mt-0 md:-mt-0 lg:-ml-4 md:-ml-4 sm:-mt-4 ">
                <h1 class="lg:text-center md:text-justify pt-6 font-extrabold text-indigo-800 lg:text-5xl md:text-4xl sm:text-3xl">Hola bienvenido!!!</h1>
                <p class="pl-10 mt-2 lg:text-left text-gray-900 md:text-justify lg:text-xl font-bold">Nosotros podemos ayudarte a conocer en que carrera podrias encarjar bien</p>
                <p class="pl-10 mt-2 text-center text-gray-900  lg:text-2xl font-bold">Pequeñas instrucciones:</p>
                <p class="pl-10 mt-2 lg:text-left text-gray-900 md:text-justify lg:text-basic">- Puedes cambiar y/o actualizar tu perfil a tu gusto, asi como la preferencia que elegiste para estudiar</p>
                <p class="pl-10 mt-2 lg:text-left text-gray-900 md:text-justify lg:text-basic">- Las actividades son asignadas por tu asesor, el cual, puedes aceptar o rechazar dicha actividad, bajo tu propia responsabilidad</p>
                <p class="pl-10 mt-2 lg:text-left text-gray-900 md:text-justify lg:text-basic">- Tus registros se quedan guardados y puedes ver los logros de tu perfil</p>
                <p class="pl-10 mt-2 lg:text-left text-gray-900 md:text-justify lg:text-basic">- Se libre de administrar tu perfil, actividades y etc.</p>
            </div>
            <div class="lg:basis-1/3 md:basis-6/12 sm:basis-11/12  px-8 pb-2 ">
                <h1 class="text-justify font-black text-indigo-800 pt-6 lg:text-3xl md:text-2xl sm:text-xl">Actividades pendientes</h1>
                @if(count($pen)>0)
                <div class="w-10/12 mx-auto py-8">
                    @foreach($pen as $object)
                    <p class="text-justify text-gray-900 p-2">*{{$object->tema}}</p>
                    @endforeach
                    <a class="bg-cyan-600 rounded-full px-2 ml-4" href="{{route('actividad.index')}}">Ver lista</a>
                </div>
                @endif
            </div>
        </div>
        @else
        <div class="w-full flex flex-wrap h-full">
            <div class="lg:basis-11/12 mx-auto pb-6 rounded-md md:basis-11/12 sm:basis-11/12 bg-white">
                <h1 class="lg:text-center md:text-center sm:text-center pt-6 font-extrabold text-indigo-800 lg:text-5xl md:text-4xl sm:text-3xl py-4">Para empezar</h1>
                <p class="pl-10 mt-1 lg:text-left text-gray-900 md:text-justify lg:text-xl font-bold">Gracias por registrarte a nuestra plataforma, a continuación, verifica lo siguiente</p>
                <div class="flex flex-wrap px-6">
                    <div class="lg:basis-6/12 md:basis-full sm:basis-full">
                        <br>
                        <p class="px-5 mt-1 text-justify  text-xl text-gray-500">Primero que nada, debes saber que tu, propones tus metas. Te ofrecemos ayuda para que puedas elegir la carrera que te gusta, basandonos en algunas actividades que nosotros los asesores te proporcionaremos mas adelante.</p>
                        <br>
                        <p class="px-5 mt-1 text-justify text-black text-xl">Una vez dicho esto, por favor, se amable de completar tu perfil para que puedas comenzar a explorar por la aplicación.</p>
                        <div class="w-5/12 mx-auto mt-8">
                            <button class="flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 md:py-4 md:text-lg md:px-10" wire:click="mostrar">Completa tu perfil</button>
                        </div>
                    </div>
                    <div class="lg:basis-6/12 md:basis-full sm:basis-full">
                        @if($createMode)
                        @include('perfilp.create')
                        @endif
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>
</div>