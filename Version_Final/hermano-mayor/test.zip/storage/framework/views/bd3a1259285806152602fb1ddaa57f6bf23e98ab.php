<form class="w-11/12 mx-auto" action="/curso" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="carrera" value="<?php echo e($carrera); ?>">
        <input type="hidden" name="tema" value="<?php echo e($tema); ?>">
        <input type="hidden" name="descripcion" value="<?php echo e($descripcion); ?>">
        <input type="hidden" name="estado" value="Pendiente">
        <input type="hidden" name="finalizado" value="No finalizado">
        <input type="hidden" name="historial2" value="'<?php echo e($nombre); ?>', te asigno una nueva actividad '<?php echo e($tema); ?>'">
        <label class="block mb-2 text-lg text-gray-800 dark:text-gray-200">Escoja a su estudiante:</label>
        <select  name="prospecto_id"
                class="block appearance-none w-full bg-gray-200 border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                id="especialidad">
                <?php $__currentLoopData = $nuevo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($object->user_id); ?>"><?php echo e($object->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full">Agregar</button>
</form><?php /**PATH C:\xampp\htdocs\hermano-mayor\resources\views/curso/add.blade.php ENDPATH**/ ?>