
<?php $__env->startSection('mayor'); ?>
<div class="w-full mx-auto h-auto lg:mt-5 sm:mt-8">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('crear-curso')->html();
} elseif ($_instance->childHasBeenRendered('BVh18GD')) {
    $componentId = $_instance->getRenderedChildComponentId('BVh18GD');
    $componentTag = $_instance->getRenderedChildComponentTagName('BVh18GD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BVh18GD');
} else {
    $response = \Livewire\Livewire::mount('crear-curso');
    $html = $response->html();
    $_instance->logRenderedChild('BVh18GD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\canch\Downloads\hermano-mayor\hermano-mayor\resources\views/curso/create.blade.php ENDPATH**/ ?>