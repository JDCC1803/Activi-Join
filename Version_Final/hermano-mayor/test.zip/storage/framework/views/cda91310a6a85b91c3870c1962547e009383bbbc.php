
<?php $__env->startSection('mayor'); ?>
<div class="container mx-auto lg:mt-5 sm:mt-8">
    <?php if(count($ver)>0): ?>
        <div class="w-11/12 mx-auto flex flex-wrap h-full lg:space-x-2 md:space-x-2 lg:space-y-0 md:space-y-0 sm:space-y-2">
            <div class="lg:basis-3/12 md:basis-5/12 sm:basis-full h-96 -ml-4 bg-white rounded-xl pt-4">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('foto-perfila')->html();
} elseif ($_instance->childHasBeenRendered('5TBCoip')) {
    $componentId = $_instance->getRenderedChildComponentId('5TBCoip');
    $componentTag = $_instance->getRenderedChildComponentTagName('5TBCoip');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5TBCoip');
} else {
    $response = \Livewire\Livewire::mount('foto-perfila');
    $html = $response->html();
    $_instance->logRenderedChild('5TBCoip', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <div class="lg:basis-8/12 md:basis-7/12 py-4 sm:basis-full -ml-4 bg-white rounded-xl">
                <?php $__currentLoopData = $ver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1 class="text-gray-900 text-center text-2xl font-bold">Datos de usuario</h1>
                <p class="text-gray-900 text-justify px-8 pt-8 font-bold">Nombre: </p>
                <p class="text-gray-900 text-justify px-8 pt-1 font-bold"><?php echo e($object->name); ?></p>
                <p class="text-gray-900 text-justify px-8 pt-4 font-bold">Especialidad: </p>
                <p class="text-gray-900 text-justify px-8 pt-1 font-bold"><?php echo e($object->especialidad); ?></p>
                <p class="text-gray-900 text-justify px-8 pt-4 font-bold">Grado y grupo: </p>
                <p class="text-gray-900 text-justify px-8 pt-1 font-bold"><?php echo e($object->grado); ?><?php echo e($object->grupo); ?></p>
                <p class="text-gray-900 text-justify px-8 pt-4 font-bold">Breve descripción de tu persona: </p>
                <p class="text-gray-900 text-justify px-8 pt-1 font-bold"><?php echo e($object->descripcion); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ver-perfila')->html();
} elseif ($_instance->childHasBeenRendered('WwNuGCz')) {
    $componentId = $_instance->getRenderedChildComponentId('WwNuGCz');
    $componentTag = $_instance->getRenderedChildComponentTagName('WwNuGCz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WwNuGCz');
} else {
    $response = \Livewire\Livewire::mount('ver-perfila');
    $html = $response->html();
    $_instance->logRenderedChild('WwNuGCz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php else: ?>
        <div class="w-10/12 mx-auto flex flex-wrap h-full  lg:space-x-2 md:space-x-2 lg:space-y-0 md:space-y-0 sm:space-y-2">
            <div class="px-4 basis-full h-64 bg-white   lg:-mt-0 md:-mt-0 lg:-ml-4 md:-ml-4 sm:-mt-4 rounded-xl">
                <h1 class="lg:text-center md:text-justify pt-6 font-extrabold text-indigo-800 lg:text-5xl md:text-4xl sm:text-3xl">Regresa al menu de inicio y completa tu perfil >:(</h1>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hermano-mayor\resources\views/perfila/perfila.blade.php ENDPATH**/ ?>