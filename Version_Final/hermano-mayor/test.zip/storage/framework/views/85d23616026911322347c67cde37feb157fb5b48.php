<div>
    

    <h1 class="text-gray-900 text-center text-lg font-bold">Imagen de perfil</h1>
    <div class="mt-8 w-9/12 h-6/12 rounded-full bg-white relative mx-auto">
        <button wire:click="abrirModal" class="absolute -bottom-6 right-0"><span
                class="material-icons">border_color</span></button>
        <img src="<?php echo e($urlfoto); ?>" alt="foto de perfil" class="object-cover rounded-full w-full h-60">
    </div>
    <?php if($open): ?>
    <div class="transition-opacity ease-in-out delay-150 animated fadeIn faster  fixed  left-0 top-0 flex justify-center items-center inset-0 z-50 outline-none focus:outline-none bg-no-repeat bg-center bg-cover"
        id="modal-id">
        <div class="absolute bg-black opacity-80 inset-0 z-0"></div>
        <div class="w-full  max-w-lg px-12 py-10 relative mx-auto my-auto rounded-xl shadow-lg  bg-white ">
            <!--content-->
            <h3 class="text-2xl mb-3">Selecciona tu foto de perfil</h3>
            <form wire:submit.prevent="save">
                <div>
                    <!--body-->

                    <div class="flex items-center space-x-6">
                        <div class="shrink-0">
                            <?php if($photo): ?>
                            <img src="<?php echo e($photo->temporaryUrl()); ?>" class="h-16 w-16 object-cover rounded-full">
                            <?php else: ?>
                            <img class="h-16 w-16 object-cover rounded-full" src="<?php echo e($urlfoto); ?>"
                                alt="foto por defecto" />
                            <?php endif; ?>

                        </div>
                        <label class="block">
                            <span class="sr-only">Choose profile photo</span>
                            <input type="file" wire:model="photo" class="block w-full text-sm text-slate-500
                                        file:mr-4 file:py-2 file:px-4
                                        file:rounded-full file:border-0
                                        file:text-sm file:font-semibold
                                        file:bg-yellow-300 file:text-yellow-700
                                        hover:file:bg-yellow-100
                                        " />
                        </label>

                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!--footer-->
                    <div class="flex gap-4  mt-5 justify-end">
                        <button wire:click="cerrarModal">Cancelar</button>
                        <button>Listo</button>
                    </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\hermano-mayor\resources\views/livewire/foto-perfil.blade.php ENDPATH**/ ?>