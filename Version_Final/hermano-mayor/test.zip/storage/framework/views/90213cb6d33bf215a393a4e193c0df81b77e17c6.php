<div class="flex flex-wrap w-11/12 mx-auto">
    <div class="basis-full h-96 -ml-4 bg-white rounded-xl pt-4">
        <h1 class="text-gray-900 text-center text-2xl font-bold">Logros adquiridos:</h1>
        <p class="mt-10 px-12 text-gray-900 text-justify text-lg font-semibold">Sección de logros para que puedas observar en que destacas sobre otros </p>
    </div>
</div><?php /**PATH C:\xampp\htdocs\hermano-mayor\resources\views/perfilp/logros.blade.php ENDPATH**/ ?>