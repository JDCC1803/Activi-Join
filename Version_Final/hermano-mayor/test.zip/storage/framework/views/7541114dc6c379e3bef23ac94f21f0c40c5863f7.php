
<?php $__env->startSection('menor'); ?>
<div class="w-full mx-auto h-auto lg:mt-5 sm:mt-8">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ver-actividad')->html();
} elseif ($_instance->childHasBeenRendered('n6hPkdY')) {
    $componentId = $_instance->getRenderedChildComponentId('n6hPkdY');
    $componentTag = $_instance->getRenderedChildComponentTagName('n6hPkdY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('n6hPkdY');
} else {
    $response = \Livewire\Livewire::mount('ver-actividad');
    $html = $response->html();
    $_instance->logRenderedChild('n6hPkdY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hermano-mayor\resources\views/actividad/actividad.blade.php ENDPATH**/ ?>