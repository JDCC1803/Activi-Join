
<?php $__env->startSection('mayor'); ?>
<div class="w-full mx-auto h-auto lg:mt-5 sm:mt-8">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('agregar-miembro')->html();
} elseif ($_instance->childHasBeenRendered('3XNdhCY')) {
    $componentId = $_instance->getRenderedChildComponentId('3XNdhCY');
    $componentTag = $_instance->getRenderedChildComponentTagName('3XNdhCY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3XNdhCY');
} else {
    $response = \Livewire\Livewire::mount('agregar-miembro');
    $html = $response->html();
    $_instance->logRenderedChild('3XNdhCY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\canch\Downloads\hermano-mayor\hermano-mayor\resources\views/hijo/create.blade.php ENDPATH**/ ?>