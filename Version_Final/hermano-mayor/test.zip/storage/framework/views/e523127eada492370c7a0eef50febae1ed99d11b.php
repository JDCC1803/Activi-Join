<div>
    
    <div class="lg:w-3/12 sm:w-5/12 mx-auto my-8">
        <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full"
            wire:click="migrupo">Mis miembros</button>
        <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full"
            wire:click="agregar">Agregar a tu grupo</button>
    </div>
    <?php if($verMode): ?>
        <?php echo $__env->make('hijo.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if($agregarMode): ?>
        <?php echo $__env->make('hijo.agregar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\hermano-mayor\resources\views/livewire/agregar-miembro.blade.php ENDPATH**/ ?>