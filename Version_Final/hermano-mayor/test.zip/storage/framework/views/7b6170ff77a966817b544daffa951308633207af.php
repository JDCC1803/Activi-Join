
<?php $__env->startSection('mayor'); ?>
<div class="w-full mx-auto h-auto lg:mt-5 sm:mt-8">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('crear-curso')->html();
} elseif ($_instance->childHasBeenRendered('v995mw1')) {
    $componentId = $_instance->getRenderedChildComponentId('v995mw1');
    $componentTag = $_instance->getRenderedChildComponentTagName('v995mw1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('v995mw1');
} else {
    $response = \Livewire\Livewire::mount('crear-curso');
    $html = $response->html();
    $_instance->logRenderedChild('v995mw1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hermano-mayor\resources\views/curso/create.blade.php ENDPATH**/ ?>