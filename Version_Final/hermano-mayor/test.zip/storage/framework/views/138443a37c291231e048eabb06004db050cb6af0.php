<div class="basis-3/12 bg-green-300 rounded-xl h-auto max-h-max text-left pt-4 pb-12">
    <div class="w-2/12 ml-auto">
        <button class=" bg-red-700 rounded-full px-2" wire:click="close"><i class="material-icons mt-1 text-white">close</i></button>
    </div>
    <h1 class="text-gray-900 px-6 text-lg font-bold"><?php echo e($tema); ?></h1>
    
    <p class="text-gray-900 px-6 text-base"><b>Descripción:</b> <?php echo e($descripcion); ?></p>
    <p class="text-gray-900 px-6 text-base"><b>Para:</b> <?php echo e($carrera); ?></p>
    <button class="bg-green-700 rounded-full px-2" wire:click="create">Asignar actividad</button>
    <?php if($crearForm): ?>
        <?php echo $__env->make('curso.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH C:\Users\canch\Downloads\hermano-mayor\hermano-mayor\resources\views/curso/mostrar.blade.php ENDPATH**/ ?>