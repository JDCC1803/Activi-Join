
<?php $__env->startSection('menor'); ?>
<div class="w-full mx-auto h-auto lg:mt-5 sm:mt-8">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ver-actividad')->html();
} elseif ($_instance->childHasBeenRendered('GOhH93E')) {
    $componentId = $_instance->getRenderedChildComponentId('GOhH93E');
    $componentTag = $_instance->getRenderedChildComponentTagName('GOhH93E');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GOhH93E');
} else {
    $response = \Livewire\Livewire::mount('ver-actividad');
    $html = $response->html();
    $_instance->logRenderedChild('GOhH93E', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\canch\Downloads\hermano-mayor\hermano-mayor\resources\views/actividad/actividad.blade.php ENDPATH**/ ?>