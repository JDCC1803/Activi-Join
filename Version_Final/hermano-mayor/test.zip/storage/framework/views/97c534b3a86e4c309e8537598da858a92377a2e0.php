
<?php $__env->startSection('mayor'); ?>
<div class="w-full mx-auto h-auto lg:mt-5 sm:mt-8">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('agregar-miembro')->html();
} elseif ($_instance->childHasBeenRendered('AQYxICv')) {
    $componentId = $_instance->getRenderedChildComponentId('AQYxICv');
    $componentTag = $_instance->getRenderedChildComponentTagName('AQYxICv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AQYxICv');
} else {
    $response = \Livewire\Livewire::mount('agregar-miembro');
    $html = $response->html();
    $_instance->logRenderedChild('AQYxICv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hermano-mayor\resources\views/hijo/create.blade.php ENDPATH**/ ?>