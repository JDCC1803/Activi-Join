<div>
    
    <div class="lg:w-3/12 sm:w-5/12 mx-auto mt-8">
            <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full" wire:click="historial">Ver historial</button>
            <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full" wire:click="logros">Ver mis logros</button>
    </div>
    <div class="w-11/12 mx-auto lg:mt-5 sm:mt-8">
        <?php if($historialMode): ?>
            <?php echo $__env->make('perfilp.historial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if($logrosMode): ?>
            <?php echo $__env->make('perfilp.logros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\hermano-mayor\resources\views/livewire/ver-perfila.blade.php ENDPATH**/ ?>