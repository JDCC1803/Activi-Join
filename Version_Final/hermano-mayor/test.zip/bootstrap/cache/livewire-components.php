<?php return array (
  'agregar-miembro' => 'App\\Http\\Livewire\\AgregarMiembro',
  'crear-curso' => 'App\\Http\\Livewire\\CrearCurso',
  'foto-perfil' => 'App\\Http\\Livewire\\FotoPerfil',
  'foto-perfila' => 'App\\Http\\Livewire\\FotoPerfila',
  'perfil-obligatorio' => 'App\\Http\\Livewire\\PerfilObligatorio',
  'perfila-obligatorio' => 'App\\Http\\Livewire\\PerfilaObligatorio',
  'ver-actividad' => 'App\\Http\\Livewire\\VerActividad',
  'ver-perfil' => 'App\\Http\\Livewire\\VerPerfil',
  'ver-perfila' => 'App\\Http\\Livewire\\VerPerfila',
);